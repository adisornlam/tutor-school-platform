globalThis.__timing__.logStart('Load chunks/routes/api/admin/branches.get');import { d as defineEventHandler, c as createError } from '../../../nitro/nitro.mjs';
import { r as requireAuth } from '../../../_/auth.middleware.mjs';
import { query } from '../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import '../../../_/jwt.mjs';
import 'jsonwebtoken';
import 'mysql2/promise';

const branches_get = defineEventHandler(async (event) => {
  await requireAuth(event);
  try {
    const branches = await query(
      `SELECT 
        id,
        name,
        code,
        address,
        phone,
        email,
        status,
        created_at,
        updated_at
      FROM branches
      WHERE status = 'active'
      ORDER BY name ASC`
    );
    return {
      success: true,
      data: branches
    };
  } catch (error) {
    console.error("Error fetching branches:", error);
    throw createError({
      statusCode: 500,
      message: "Failed to fetch branches"
    });
  }
});

export { branches_get as default };;globalThis.__timing__.logEnd('Load chunks/routes/api/admin/branches.get');
//# sourceMappingURL=branches.get.mjs.map
