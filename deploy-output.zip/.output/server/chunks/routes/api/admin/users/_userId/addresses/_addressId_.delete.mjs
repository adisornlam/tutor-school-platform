globalThis.__timing__.logStart('Load chunks/routes/api/admin/users/_userId/addresses/_addressId_.delete');import { d as defineEventHandler, a as getRouterParam, c as createError } from '../../../../../../nitro/nitro.mjs';
import { r as requireAuth } from '../../../../../../_/auth.middleware.mjs';
import { query, execute } from '../../../../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import '../../../../../../_/jwt.mjs';
import 'jsonwebtoken';
import 'mysql2/promise';

const _addressId__delete = defineEventHandler(async (event) => {
  await requireAuth(event);
  const userId = parseInt(getRouterParam(event, "userId") || "0");
  const addressId = parseInt(getRouterParam(event, "addressId") || "0");
  if (!userId || !addressId) {
    throw createError({
      statusCode: 400,
      message: "Invalid user ID or address ID"
    });
  }
  try {
    const addresses = await query(
      "SELECT id FROM user_addresses WHERE id = ? AND user_id = ?",
      [addressId, userId]
    );
    if (addresses.length === 0) {
      throw createError({
        statusCode: 404,
        message: "Address not found"
      });
    }
    const enrollments = await query(
      "SELECT id FROM enrollments WHERE shipping_address_id = ? LIMIT 1",
      [addressId]
    );
    if (enrollments.length > 0) {
      throw createError({
        statusCode: 400,
        message: "Cannot delete address that is used in enrollments"
      });
    }
    await execute(
      "DELETE FROM user_addresses WHERE id = ? AND user_id = ?",
      [addressId, userId]
    );
    return {
      success: true,
      message: "Address deleted successfully"
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    console.error("Error deleting user address:", error);
    throw createError({
      statusCode: 500,
      message: "Failed to delete user address"
    });
  }
});

export { _addressId__delete as default };;globalThis.__timing__.logEnd('Load chunks/routes/api/admin/users/_userId/addresses/_addressId_.delete');
//# sourceMappingURL=_addressId_.delete.mjs.map
