globalThis.__timing__.logStart('Load chunks/routes/api/admin/users/_userId/addresses.get');import { d as defineEventHandler, a as getRouterParam, c as createError } from '../../../../../nitro/nitro.mjs';
import { r as requireAuth } from '../../../../../_/auth.middleware.mjs';
import { query } from '../../../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import '../../../../../_/jwt.mjs';
import 'jsonwebtoken';
import 'mysql2/promise';

const addresses_get = defineEventHandler(async (event) => {
  await requireAuth(event);
  const userId = parseInt(getRouterParam(event, "userId") || "0");
  if (!userId) {
    throw createError({
      statusCode: 400,
      message: "Invalid user ID"
    });
  }
  try {
    const addresses = await query(
      `SELECT 
        id,
        user_id,
        address_type,
        recipient_name,
        phone,
        address_line1,
        address_line2,
        subdistrict,
        district,
        province,
        postal_code,
        country,
        is_default,
        created_at,
        updated_at
      FROM user_addresses
      WHERE user_id = ?
      ORDER BY is_default DESC, created_at ASC`,
      [userId]
    );
    return {
      success: true,
      data: addresses
    };
  } catch (error) {
    console.error("Error fetching user addresses:", error);
    throw createError({
      statusCode: 500,
      message: "Failed to fetch user addresses"
    });
  }
});

export { addresses_get as default };;globalThis.__timing__.logEnd('Load chunks/routes/api/admin/users/_userId/addresses.get');
//# sourceMappingURL=addresses.get.mjs.map
