globalThis.__timing__.logStart('Load chunks/routes/api/admin/courses.get');import { d as defineEventHandler, g as getQuery, c as createError } from '../../../nitro/nitro.mjs';
import { r as requireAuth } from '../../../_/auth.middleware.mjs';
import { query } from '../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import '../../../_/jwt.mjs';
import 'jsonwebtoken';
import 'mysql2/promise';

const courses_get = defineEventHandler(async (event) => {
  await requireAuth(event);
  const queryParams = getQuery(event);
  const search = queryParams.search;
  const type = queryParams.type;
  const status = queryParams.status;
  let sql = `
    SELECT 
      c.id,
      c.title,
      c.description,
      c.type,
      c.price,
      c.duration_hours,
      c.level,
      c.status,
      c.code,
      c.created_at,
      c.updated_at,
      u.first_name as created_by_name,
      u.last_name as created_by_last_name
    FROM courses c
    LEFT JOIN users u ON c.created_by = u.id
    WHERE 1=1
  `;
  const params = [];
  if (search) {
    sql += ` AND (c.title LIKE ? OR c.code LIKE ? OR c.description LIKE ?)`;
    const searchPattern = `%${search}%`;
    params.push(searchPattern, searchPattern, searchPattern);
  }
  if (type) {
    sql += ` AND c.type = ?`;
    params.push(type);
  }
  if (status) {
    sql += ` AND c.status = ?`;
    params.push(status);
  }
  sql += ` ORDER BY c.created_at DESC`;
  try {
    const courses = await query(sql, params);
    return {
      success: true,
      data: courses
    };
  } catch (error) {
    console.error("Error fetching courses:", error);
    throw createError({
      statusCode: 500,
      message: "Failed to fetch courses"
    });
  }
});

export { courses_get as default };;globalThis.__timing__.logEnd('Load chunks/routes/api/admin/courses.get');
//# sourceMappingURL=courses.get.mjs.map
