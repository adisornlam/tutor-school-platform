globalThis.__timing__.logStart('Load chunks/routes/api/admin/settings/email/smtp.get');import { d as defineEventHandler, c as createError } from '../../../../../nitro/nitro.mjs';
import { r as requireAuth } from '../../../../../_/auth.middleware.mjs';
import { getUserRoles } from '../../../../../_/auth.service.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import '../../../../../_/jwt.mjs';
import 'jsonwebtoken';
import 'bcryptjs';
import '../../../../../_/db.mjs';
import 'mysql2/promise';
import '../../../../../_/user.types.mjs';

const smtp_get = defineEventHandler(async (event) => {
  const auth = await requireAuth(event);
  const roles = await getUserRoles(auth.userId);
  const allowedRoles = ["system_admin", "owner"];
  if (!roles.some((role) => allowedRoles.includes(role))) {
    throw createError({
      statusCode: 403,
      message: "Access denied. System Admin or Owner role required."
    });
  }
  try {
    const smtpSettings = {
      host: process.env.SMTP_HOST || "",
      port: parseInt(process.env.SMTP_PORT || "587"),
      secure: process.env.SMTP_SECURE === "true",
      username: process.env.SMTP_USERNAME || "",
      password: "",
      // Never return password
      from_email: process.env.SMTP_FROM_EMAIL || "",
      from_name: process.env.SMTP_FROM_NAME || "",
      enabled: process.env.SMTP_ENABLED === "true"
    };
    return {
      success: true,
      data: smtpSettings
    };
  } catch (error) {
    console.error("Error fetching SMTP settings:", error);
    throw createError({
      statusCode: 500,
      message: "Failed to fetch SMTP settings"
    });
  }
});

export { smtp_get as default };;globalThis.__timing__.logEnd('Load chunks/routes/api/admin/settings/email/smtp.get');
//# sourceMappingURL=smtp.get.mjs.map
