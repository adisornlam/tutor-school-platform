globalThis.__timing__.logStart('Load chunks/routes/api/admin/upload.post');import { d as defineEventHandler, f as readMultipartFormData, c as createError } from '../../../nitro/nitro.mjs';
import { r as requireAuth } from '../../../_/auth.middleware.mjs';
import { mkdir, writeFile } from 'fs/promises';
import { join } from 'path';
import { existsSync } from 'fs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import '../../../_/jwt.mjs';
import 'jsonwebtoken';

const upload_post = defineEventHandler(async (event) => {
  await requireAuth(event);
  try {
    const formData = await readMultipartFormData(event);
    if (!formData || formData.length === 0) {
      throw createError({
        statusCode: 400,
        message: "No file uploaded"
      });
    }
    const file = formData[0];
    if (!file.filename || !file.data) {
      throw createError({
        statusCode: 400,
        message: "Invalid file"
      });
    }
    const allowedTypes = ["image/jpeg", "image/jpg", "image/png", "image/gif", "image/webp"];
    if (!file.type || !allowedTypes.includes(file.type)) {
      throw createError({
        statusCode: 400,
        message: "Only image files are allowed (JPEG, PNG, GIF, WebP)"
      });
    }
    const maxSize = 5 * 1024 * 1024;
    if (file.data.length > maxSize) {
      throw createError({
        statusCode: 400,
        message: "File size exceeds 5MB limit"
      });
    }
    const timestamp = Date.now();
    const randomString = Math.random().toString(36).substring(2, 15);
    const extension = file.filename.split(".").pop();
    const filename = `${timestamp}-${randomString}.${extension}`;
    const uploadsDir = join(process.cwd(), "public", "uploads", "courses");
    if (!existsSync(uploadsDir)) {
      await mkdir(uploadsDir, { recursive: true });
    }
    const filePath = join(uploadsDir, filename);
    await writeFile(filePath, file.data);
    const publicUrl = `/uploads/courses/${filename}`;
    return {
      success: true,
      data: {
        url: publicUrl,
        filename,
        originalName: file.filename,
        size: file.data.length,
        type: file.type
      }
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    console.error("Error uploading file:", error);
    throw createError({
      statusCode: 500,
      message: "Failed to upload file"
    });
  }
});

export { upload_post as default };;globalThis.__timing__.logEnd('Load chunks/routes/api/admin/upload.post');
//# sourceMappingURL=upload.post.mjs.map
