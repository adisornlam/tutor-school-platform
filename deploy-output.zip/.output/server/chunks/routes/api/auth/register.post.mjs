globalThis.__timing__.logStart('Load chunks/routes/api/auth/register.post');import { d as defineEventHandler, r as readBody, c as createError, s as setCookie } from '../../../nitro/nitro.mjs';
import { createUser, getUserWithRoles } from '../../../_/auth.service.mjs';
import { g as generateAccessToken, a as generateRefreshToken } from '../../../_/jwt.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'bcryptjs';
import '../../../_/db.mjs';
import 'mysql2/promise';
import '../../../_/user.types.mjs';
import 'jsonwebtoken';

const register_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  if (!body.username || !body.password || !body.first_name || !body.last_name) {
    throw createError({
      statusCode: 400,
      message: "Username, password, first name, and last name are required"
    });
  }
  const { findUserByIdentifier } = await import('../../../_/auth.service.mjs');
  const existingUser = await findUserByIdentifier(body.username);
  if (existingUser) {
    throw createError({
      statusCode: 409,
      message: "Username already registered"
    });
  }
  if (body.email) {
    const { findUserByEmail } = await import('../../../_/auth.service.mjs');
    const existingEmailUser = await findUserByEmail(body.email);
    if (existingEmailUser) {
      throw createError({
        statusCode: 409,
        message: "Email already registered"
      });
    }
  }
  const user = await createUser(body);
  if (body.role) {
    const { queryOne, execute: execute2 } = await import('../../../_/db.mjs');
    const roleRecord = await queryOne(
      "SELECT id FROM roles WHERE name = ?",
      [body.role]
    );
    if (roleRecord) {
      await execute2(
        "DELETE FROM user_roles WHERE user_id = ?",
        [user.id]
      );
      await execute2(
        "INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)",
        [user.id, roleRecord.id]
      );
    }
  }
  const userWithRoles = await getUserWithRoles(user.id);
  if (!userWithRoles) {
    throw createError({
      statusCode: 500,
      message: "Failed to create user"
    });
  }
  const accessToken = generateAccessToken(userWithRoles);
  const refreshToken = generateRefreshToken(user.id);
  const { execute } = await import('../../../_/db.mjs');
  const expiresAt = /* @__PURE__ */ new Date();
  expiresAt.setDate(expiresAt.getDate() + 7);
  await execute(
    `INSERT INTO refresh_tokens (user_id, token, expires_at)
     VALUES (?, ?, ?)`,
    [user.id, refreshToken, expiresAt]
  );
  setCookie(event, "access_token", accessToken, {
    httpOnly: true,
    secure: true,
    sameSite: "strict",
    maxAge: 15 * 60
  });
  setCookie(event, "refresh_token", refreshToken, {
    httpOnly: true,
    secure: true,
    sameSite: "strict",
    maxAge: 7 * 24 * 60 * 60
  });
  return {
    success: true,
    data: {
      user: userWithRoles,
      accessToken
    }
  };
});

export { register_post as default };;globalThis.__timing__.logEnd('Load chunks/routes/api/auth/register.post');
//# sourceMappingURL=register.post.mjs.map
