globalThis.__timing__.logStart('Load chunks/virtual/_virtual_spa-template');const template = "";

export { template };;globalThis.__timing__.logEnd('Load chunks/virtual/_virtual_spa-template');
//# sourceMappingURL=_virtual_spa-template.mjs.map
