globalThis.__timing__.logStart('Load chunks/_/jwt');import { u as useRuntimeConfig, c as createError } from '../nitro/nitro.mjs';
import jwt from 'jsonwebtoken';

const config = useRuntimeConfig();
function generateAccessToken(user) {
  const payload = {
    userId: user.id,
    email: user.email,
    roles: user.roles
  };
  return jwt.sign(payload, config.jwtSecret, {
    expiresIn: config.jwtExpiresIn
  });
}
function generateRefreshToken(userId) {
  return jwt.sign({ userId }, config.jwtRefreshSecret, {
    expiresIn: config.jwtRefreshExpiresIn
  });
}
function verifyAccessToken(token) {
  try {
    return jwt.verify(token, config.jwtSecret);
  } catch (error) {
    throw createError({
      statusCode: 401,
      message: "Invalid or expired token"
    });
  }
}

export { generateRefreshToken as a, generateAccessToken as g, verifyAccessToken as v };;globalThis.__timing__.logEnd('Load chunks/_/jwt');
//# sourceMappingURL=jwt.mjs.map
