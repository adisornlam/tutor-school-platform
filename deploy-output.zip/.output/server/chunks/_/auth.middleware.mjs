globalThis.__timing__.logStart('Load chunks/_/auth.middleware');import { b as getCookie, e as getHeader, c as createError } from '../nitro/nitro.mjs';
import { v as verifyAccessToken } from './jwt.mjs';

async function requireAuth(event) {
  var _a;
  const token = getCookie(event, "access_token") || ((_a = getHeader(event, "authorization")) == null ? void 0 : _a.replace("Bearer ", ""));
  if (!token) {
    throw createError({
      statusCode: 401,
      message: "Authentication required"
    });
  }
  try {
    const payload = verifyAccessToken(token);
    event.context.user = payload;
    return payload;
  } catch (error) {
    throw createError({
      statusCode: 401,
      message: "Invalid or expired token"
    });
  }
}

export { requireAuth as r };;globalThis.__timing__.logEnd('Load chunks/_/auth.middleware');
//# sourceMappingURL=auth.middleware.mjs.map
