globalThis.__timing__.logStart('Load chunks/_/user.types');var UserStatus = /* @__PURE__ */ ((UserStatus2) => {
  UserStatus2["ACTIVE"] = "active";
  UserStatus2["INACTIVE"] = "inactive";
  UserStatus2["SUSPENDED"] = "suspended";
  return UserStatus2;
})(UserStatus || {});
var UserRole = /* @__PURE__ */ ((UserRole2) => {
  UserRole2["STUDENT"] = "student";
  UserRole2["TUTOR"] = "tutor";
  UserRole2["PARENT"] = "parent";
  UserRole2["BRANCH_ADMIN"] = "branch_admin";
  UserRole2["ADMIN"] = "admin";
  UserRole2["OWNER"] = "owner";
  UserRole2["SYSTEM_ADMIN"] = "system_admin";
  return UserRole2;
})(UserRole || {});
const ROLE_PRIORITY = {
  ["system_admin" /* SYSTEM_ADMIN */]: 1,
  ["owner" /* OWNER */]: 2,
  ["admin" /* ADMIN */]: 3,
  ["branch_admin" /* BRANCH_ADMIN */]: 4,
  ["tutor" /* TUTOR */]: 5,
  ["parent" /* PARENT */]: 6,
  ["student" /* STUDENT */]: 7
};
function getHighestPriorityRole(roles) {
  if (!roles || roles.length === 0) return null;
  return roles.reduce((highest, role) => {
    const currentPriority = ROLE_PRIORITY[role] || 999;
    const highestPriority = ROLE_PRIORITY[highest] || 999;
    return currentPriority < highestPriority ? role : highest;
  });
}
function hasRoleOrHigher(userRoles, minRole) {
  if (!userRoles || userRoles.length === 0) return false;
  const minPriority = ROLE_PRIORITY[minRole] || 999;
  return userRoles.some((role) => {
    const rolePriority = ROLE_PRIORITY[role] || 999;
    return rolePriority <= minPriority;
  });
}

export { ROLE_PRIORITY, UserRole, UserStatus, getHighestPriorityRole, hasRoleOrHigher };;globalThis.__timing__.logEnd('Load chunks/_/user.types');
//# sourceMappingURL=user.types.mjs.map
