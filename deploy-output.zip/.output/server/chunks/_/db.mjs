globalThis.__timing__.logStart('Load chunks/_/db');import { u as useRuntimeConfig } from '../nitro/nitro.mjs';
import mysql from 'mysql2/promise';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';

let pool = null;
function getDatabase() {
  const config = useRuntimeConfig();
  if (!pool) {
    pool = mysql.createPool({
      host: config.dbHost,
      port: config.dbPort,
      database: config.dbName,
      user: config.dbUser,
      password: config.dbPassword,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      timezone: "+07:00",
      // Asia/Bangkok
      dateStrings: false
    });
  }
  return pool;
}
async function query(sql, params) {
  const db = getDatabase();
  const [rows] = await db.execute(sql, params);
  return rows;
}
async function queryOne(sql, params) {
  const results = await query(sql, params);
  return results[0] || null;
}
async function execute(sql, params) {
  const db = getDatabase();
  const [result] = await db.execute(sql, params);
  return result;
}

export { execute, getDatabase, query, queryOne };;globalThis.__timing__.logEnd('Load chunks/_/db');
//# sourceMappingURL=db.mjs.map
