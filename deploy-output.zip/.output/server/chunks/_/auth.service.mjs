globalThis.__timing__.logStart('Load chunks/_/auth.service');import { c as createError } from '../nitro/nitro.mjs';
import bcrypt from 'bcryptjs';
import { query, queryOne, execute } from './db.mjs';
import { g as generateAccessToken, a as generateRefreshToken } from './jwt.mjs';
import { UserRole, UserStatus } from './user.types.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'mysql2/promise';
import 'jsonwebtoken';

async function findUserByEmail(email) {
  return queryOne(
    "SELECT * FROM users WHERE email = ?",
    [email]
  );
}
async function findUserByIdentifier(identifier) {
  return queryOne(
    "SELECT * FROM users WHERE username = ? OR email = ?",
    [identifier, identifier]
  );
}
async function findUserById(id) {
  return queryOne(
    "SELECT * FROM users WHERE id = ?",
    [id]
  );
}
async function getUserRoles(userId) {
  const roles = await query(
    `SELECT r.name 
     FROM user_roles ur
     JOIN roles r ON ur.role_id = r.id
     WHERE ur.user_id = ?`,
    [userId]
  );
  return roles.map((r) => r.name);
}
async function getUserWithRoles(userId) {
  const user = await findUserById(userId);
  if (!user) return null;
  const roles = await getUserRoles(userId);
  const { password_hash, ...publicUser } = user;
  return { ...publicUser, roles };
}
async function createUser(data, defaultRole = UserRole.STUDENT) {
  const passwordHash = await bcrypt.hash(data.password, 12);
  const result = await execute(
    `INSERT INTO users (username, email, password_hash, first_name, last_name, phone, status)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      data.username,
      data.email || null,
      passwordHash,
      data.first_name,
      data.last_name,
      data.phone || null,
      UserStatus.ACTIVE
    ]
  );
  const role = await queryOne(
    "SELECT id FROM roles WHERE name = ?",
    [defaultRole]
  );
  if (role) {
    await execute(
      "INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)",
      [result.insertId, role.id]
    );
  }
  const user = await findUserById(result.insertId);
  if (!user) throw createError({ statusCode: 500, message: "Failed to create user" });
  return user;
}
async function verifyPassword(password, hash) {
  return bcrypt.compare(password, hash);
}
async function login(credentials) {
  console.log("[Auth Service] Finding user by identifier:", credentials.username);
  const user = await findUserByIdentifier(credentials.username);
  if (!user) {
    console.log("[Auth Service] User not found:", credentials.username);
    throw createError({
      statusCode: 401,
      message: "Invalid username or password"
    });
  }
  console.log("[Auth Service] User found:", user.id, user.username, user.status);
  if (user.status !== UserStatus.ACTIVE) {
    console.log("[Auth Service] Account is not active:", user.status);
    throw createError({
      statusCode: 403,
      message: "Account is not active"
    });
  }
  console.log("[Auth Service] Getting password hash for user:", user.id);
  const userWithPassword = await queryOne(
    "SELECT password_hash FROM users WHERE id = ?",
    [user.id]
  );
  if (!userWithPassword) {
    console.log("[Auth Service] Password hash not found for user:", user.id);
    throw createError({
      statusCode: 401,
      message: "Invalid username or password"
    });
  }
  console.log("[Auth Service] Verifying password...");
  const isValid = await verifyPassword(credentials.password, userWithPassword.password_hash);
  if (!isValid) {
    console.log("[Auth Service] Password verification failed");
    throw createError({
      statusCode: 401,
      message: "Invalid username or password"
    });
  }
  console.log("[Auth Service] Password verified successfully");
  const userWithRoles = await getUserWithRoles(user.id);
  if (!userWithRoles) {
    throw createError({
      statusCode: 500,
      message: "Failed to get user roles"
    });
  }
  const accessToken = generateAccessToken(userWithRoles);
  const refreshToken = generateRefreshToken(user.id);
  const expiresAt = /* @__PURE__ */ new Date();
  expiresAt.setDate(expiresAt.getDate() + 7);
  await execute(
    `INSERT INTO refresh_tokens (user_id, token, expires_at)
     VALUES (?, ?, ?)`,
    [user.id, refreshToken, expiresAt]
  );
  return {
    user: userWithRoles,
    accessToken,
    refreshToken
  };
}

export { createUser, findUserByEmail, findUserById, findUserByIdentifier, getUserRoles, getUserWithRoles, login, verifyPassword };;globalThis.__timing__.logEnd('Load chunks/_/auth.service');
//# sourceMappingURL=auth.service.mjs.map
