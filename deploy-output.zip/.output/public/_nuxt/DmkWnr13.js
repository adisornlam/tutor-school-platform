import{_ as m}from"./CbkqHqNl.js";import"./0ygRV2f8.js";export{m as default};
